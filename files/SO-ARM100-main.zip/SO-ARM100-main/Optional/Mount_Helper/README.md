# Helper piece to mount your so100

Inserting the rectangular hollow pieces can be quite difficult.

To make it easier to assemble, we propose this helper piece that will allow you to push with ease.

Here's a short video of how to use it.

<video src="https://github.com/user-attachments/assets/e1095e7a-b974-4ff0-b3d9-2820359dface"></video>
